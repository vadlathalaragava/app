import { Component, OnInit } from '@angular/core';
import CustomerService from '../customer.service';

@Component({
  selector: 'app-addcustomer',
  templateUrl: './addcustomer.component.html',
  styleUrls: ['./addcustomer.component.scss'],
})
export class AddcustomerComponent implements OnInit {

  constructor(private CustomerService:CustomerService) {


  }
  addCustomer(customer){
      this.CustomerService.addCustomers(customer);
      this.CustomerService.getCustomers();

    }
    deleteAllStudents(students){
      this.CustomerService.deleteAllStudents(students);
      this.CustomerService.getStudents();
      
    }
    deleteStudent(a){
      this.CustomerService.deleteStudent(a);
     
    }
  ngOnInit() {}

}
