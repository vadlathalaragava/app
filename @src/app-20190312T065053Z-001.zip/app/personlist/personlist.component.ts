import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-personlist',
  templateUrl: './personlist.component.html',
  styleUrls: ['./personlist.component.scss'],
})
export class PersonlistComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
