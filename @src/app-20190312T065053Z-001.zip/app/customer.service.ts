import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export default class CustomerService {
 
customers:any=[{ id: 11, name: 'Mr. Nice',email:'nick@email.com', mobile:'23124235',address:'silk board bilwara' },
{ id: 12, name: 'Narco',email:'narco@email.com', mobile:'23124235',address:'silk board bilwara' }];

  getCustomers(){
    return this.customers;
  }
  addCustomers(customer){
    var updated = false;
    for(var i = 0; i < this.customers.length; i++){
      if(customer.id == this.customers[i].id){
        updated = true;
        this.customers[i] = customer;
        break;
      }
    }
  if(!updated){
    customer.id = Math.round(Math.random()*1000000);
    this.customers.push(customer);
  }
  }
  deleteAllcustomers(id){
    for(var i = 0; i< this.customers.length; i++){
      this.customers.splice(i, this.customers.length);
    }
  }
  deleteCustomer(c){
    for(var i = 0; i< this.customers.length; i++){
      if(c.id == this.customers[i].id){
        this.customers.splice(i, c.id);
      }
    }
  }
}
